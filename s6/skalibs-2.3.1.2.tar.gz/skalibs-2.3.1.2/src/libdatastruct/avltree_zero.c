/* ISC license. */

#include <skalibs/avltree.h>

avltree const avltree_zero = AVLTREE_ZERO ;
