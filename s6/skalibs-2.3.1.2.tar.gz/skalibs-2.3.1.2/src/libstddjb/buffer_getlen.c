/* ISC license. */

#include <skalibs/buffer.h>

unsigned int buffer_getlen (buffer const *b)
{
  return buffer_len(b) ;
}
