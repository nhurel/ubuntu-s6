/* ISC license. */

#include <skalibs/uint64.h>
#include "fmtscan-internal.h"

SCANB0(64)
