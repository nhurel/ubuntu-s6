/* ISC license. */

#include <skalibs/uint64.h>
#include "fmtscan-internal.h"

FMTL(64)
