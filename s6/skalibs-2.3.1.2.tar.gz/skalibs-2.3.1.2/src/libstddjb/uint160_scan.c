/* ISC license. */

#include <skalibs/uint16.h>
#include "fmtscan-internal.h"

SCANB0(16)
