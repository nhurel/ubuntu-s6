/* ISC license. */

/* MT-unsafe */

#include <skalibs/tai.h>

tain_t STAMP = TAIN_EPOCH ;
