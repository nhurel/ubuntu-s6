/* ISC license. */

#include <skalibs/cdb.h>

struct cdb const cdb_zero = CDB_ZERO ;
