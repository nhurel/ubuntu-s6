/* ISC license. */

/* MT-unsafe */

#include <skalibs/random.h>

int badrandom_init (void)
{
  return 1 ;
}
