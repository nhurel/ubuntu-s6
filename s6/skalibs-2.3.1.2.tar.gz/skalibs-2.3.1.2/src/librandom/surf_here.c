/* ISC license. */

/* MT-unsafe */

#include <skalibs/surf.h>
#include "random-internal.h"

SURFSchedule surf_here = SURFSCHEDULE_ZERO ;
