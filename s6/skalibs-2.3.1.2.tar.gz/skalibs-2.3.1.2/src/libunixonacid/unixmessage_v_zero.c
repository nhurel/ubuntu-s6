/* ISC license. */

#include <skalibs/unixmessage.h>

unixmessage_v_t const unixmessage_v_zero = UNIXMESSAGE_V_ZERO ;
