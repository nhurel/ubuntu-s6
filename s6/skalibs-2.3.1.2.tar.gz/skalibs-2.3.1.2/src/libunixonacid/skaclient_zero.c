/* ISC license. */

#include <skalibs/skaclient.h>

skaclient_t const skaclient_zero = SKACLIENT_ZERO ;
