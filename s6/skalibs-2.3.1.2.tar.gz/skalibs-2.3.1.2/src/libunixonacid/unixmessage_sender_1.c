/* ISC license. */

/* MT-unsafe */

#include <skalibs/unixmessage.h>

unixmessage_sender_t unixmessage_sender_1_ = UNIXMESSAGE_SENDER_INIT(1) ;
