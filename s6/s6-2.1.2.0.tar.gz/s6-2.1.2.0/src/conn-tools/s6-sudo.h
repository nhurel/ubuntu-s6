/* ISC license. */

#ifndef S6_SUDO_H
#define S6_SUDO_H

#define S6_SUDO_BANNERB "s6-sudo b v1.0\n"
#define S6_SUDO_BANNERB_LEN (sizeof(S6_SUDO_BANNERB) - 1)
#define S6_SUDO_BANNERA "s6-sudo a v1.0\n"
#define S6_SUDO_BANNERA_LEN (sizeof(S6_SUDO_BANNERA) - 1)

#endif
